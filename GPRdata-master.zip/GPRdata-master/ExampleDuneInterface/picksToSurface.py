from gprpy.interpSurface import *

interpSurface('pick_combined.txt','surface_spline21',nxgrid=200,
              nygrid=200,method='spline',kx=2,ky=1)
