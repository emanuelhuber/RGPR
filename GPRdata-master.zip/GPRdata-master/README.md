# GPRdata

This repository contains data sets that are too large to be included in the GPRPy distribution but which can be used to explore GPRPy or for educational purposes.

GPRPy can be installed following the instructions here:

[https://nsgeophysics.github.io/GPRPy/](https://nsgeophysics.github.io/GPRPy/)
