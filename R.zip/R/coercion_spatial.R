
#' @export
setAs(from = "GPR", to = "sf",
      def = function (from) as.sf(from))

#' Coerce object to an sf POINT object
#'
#' Coerce object to a simple feature (sf) geometry POINT. 
#' Only coordinates are coerced, no additional information.
#' @param x (`class GPR|GPRsurvey`)
#' @return (`class sf`) Geometry type is `POINT`.
#' @name as.sf
#' @concept coercion
setGeneric("as.sf", function(x) 
  standardGeneric("as.sf"))


#' @rdname as.sf
#' @export
setMethod("as.sf", signature(x = "GPR"), function(x){
  if(length(x@coord) == 0){
    stop("No coordinates. Set first coordinates either with 'coordinates(x) <-'\n",
         "  or with ' interpCoords(x, ...)'.")
  }
  .as_LINESTRING(x@coord, x@name, x@crs)
})


#' @rdname as.sf
#' @export
setMethod("as.sf", signature(x = "GPRsurvey"), function(x){
  sel <- sapply(x@coords, function(x) length(x) > 0)
  if(all(!sel)){
    stop("No coordinates. Set first coordinates either with 'coordinates(x) <-'\n",
         "  or with ' interpCoords(x, ...)'.")
    
  }
  if(length(x@crs) != 1){
    stop("'crs' length must be 1")
  }
  # test <- lapply(x@coords[sel], .as_LINESTRING,  x@crs)
  test <- mapply(.as_LINESTRING,  x@coords[sel], x@names[sel], MoreArgs = list(x@crs[1]), SIMPLIFY = FALSE, USE.NAMES = FALSE)
  x_sfc <- do.call(rbind, test)
  # x_sfc <- c(test)
  x_sf <- sf::st_sf(x_sfc)
  # x_sf$names <- x@names[sel]
  x_sf$modes <- x@modes[sel]
  x_sf$dates <- x@dates[sel]
  
  if(any(!sel)){
    warning("I cannot coerce the following GPR data to 'sf' ",
           "(they don't have coordinates):\n", 
            paste0("  #", which(!sel), ": ", x@names[!sel], collapse ="\n"), 
            ".")
  }
  return(x_sf)
})



.as_LINESTRING <- function(x, id, CRS){
  if(length(x) > 0){
    xi_sf <- sf::st_as_sf(x      = as.data.frame(x),
                          coords = 1:2,
                          crs    = CRS)
    xi_sf <- sf::st_combine(xi_sf)
    xi_sf <- sf::st_cast(xi_sf, "LINESTRING")
    xi_sf <- sf::st_as_sf(xi_sf)
    xi_sf$name <- id
    return(xi_sf)
  }
}

#------------------------------ SPATIAL LINES ---------------------------------#


#' Coerce object to an object of the class SpatialLines
#'
#' Coerce object to an object of the class SpatialLines
#' @param x (`class GPR|GPRsurvey`)
#' @return (`SpatialLines object`)
#' @name as.spatialLines
#' @concept coercion
setGeneric("as.spatialLines", function(x) 
  standardGeneric("as.spatialLines"))

#' @rdname as.spatialLines
#' @export
setMethod("as.spatialLines", signature(x = "GPRsurvey"), function(x){
  as.sf(x)
})

#' @rdname as.spatialLines
#' @export
setMethod("as.spatialLines", signature(x = "GPR"), function(x){
  as.sf(x)
})


#------------------------------ SPATIAL POINTS --------------------------------#


#' Coerce object to an object of the class SpatialPoints
#'
#' Coerce object to an object of the class SpatialPoints
#' @param x (`class GPR|GPRsurvey`)
#' @return (`SpatialPoints`)
#' @name as.spatialPoints
#' @concept coercion
setGeneric("as.spatialPoints", function(x) 
  standardGeneric("as.spatialPoints"))



#' @rdname as.spatialPoints
#' @export
setMethod("as.spatialPoints", signature(x = "GPR"), function(x){
  if(length(x@coord) > 0){
    xdf <- as.data.frame(x@coord)
    names(xdf) <- c("x", "y", "z")
    if(length(x@markers) == ncol(x)) xdf['markers'] <- x@markers
    if(length(x@ann) == ncol(x)) xdf['ann'] <- x@ann
    if(length(x@time) == ncol(x)) xdf['time'] <- x@time
  
  x_sf <- sf::st_as_sf(x      = xdf,
                       coords = 1:2,
                       crs    = x@crs)
  
  return(x_sf)
  }else{
    stop("'x' has no coordinates. Please add first coordinates to 'x'!")
  }
})

#' @rdname as.spatialPoints
#' @export
setMethod("as.spatialPoints", signature(x = "GPRsurvey"), function(x){
  sel <- sapply(x@coords, function(x) length(x) > 0)
  if(all(!sel)){
    stop("No coordinates. Set first coordinates either with 'coordinates(x) <-'\n",
         "  or with ' interpCoords(x, ...)'.")
    
  }
  if(length(x@crs) != 1){
    stop("'crs' length must be 1")
  }
  fun <-function(x, x_crs){
    xdf <- as.data.frame(x)
    names(xdf) <- c("x", "y", "z")
    sf::st_as_sf(x      = xdf,
                 coords = 1:2,
                 crs    = x_crs)
  }
  Xsf <- lapply(x@coords[sel], fun, x@crs)
  x_sf <- do.call(rbind, Xsf)
  x_sf$names <- rep(x@names[sel],  x@nx[sel])
  x_sf$modes <- rep(x@modes[sel],  x@nx[sel])
  x_sf$dates <- rep(x@dates[sel],  x@nx[sel])
  
  if(any(!sel)){
    warning("I cannot coerce the following GPR data to 'sf' ",
            "(they don't have coordinates):\n", 
            paste0("  #", which(!sel), ": ", x@names[!sel], collapse ="\n"), 
            ".")
  }
  return(x_sf)
  
  
})

setGeneric("as.raster", function(x) standardGeneric("as.raster"))

#' Coercion to SpatRaster
#'
#' @name as.raster
#' @rdname GPRcoercion
#' @export
setMethod("as.raster", signature(x = "GPRslice"), function(x){
  
  r <- terra::rast(
    nrows = dim(x@data)[1],
    ncols = dim(x@data)[2],
    xmin  = x@center[1],
    xmax  = x@center[1] + x@dx * (dim(x@data)[1] - 1),
    ymin  = x@center[2],
    ymax  = x@center[2] + x@dy * (dim(x@data)[2] - 1),
    crs   = x@crs[1]
  )
  
  # terra fills by column, so transpose + reverse columns
  # r <- terra::setValues(r,    as.vector(t(x@data[, ncol(x@data):1])))
  r <- terra::setValues(r,    as.vector(t(x@data)) )
  
  return(r)
})

#' Coercion to SpatRaster (multi-layer)
#'
#' @name as.raster
#' @rdname GPRcoercion
#' @export
setMethod("as.raster", signature(x = "GPRcube"), function(x){
  
  r <- as.raster(x[,,1])
  
  for (i in 2:dim(x@data)[3]) {
    r <- terra::c(r, as.raster(x[,,i]))
  }
  
  return(r)
})
