#' Estimate and set time-zero
#' 
#' `estimateTime0` estimates for each trace individually the first wave 
#' break, computes the corresponding time-zero knowing the propagation speed
#' of the electromagnetic wave through air and returns an object of the class
#' `GPR` with updated time-zero. It is possible to apply a function 
#' provided by the user (e.g., `FUN`) on time-zero (e.g., to set time-zero
#' equal to the average value of the time-zeros computed for every traces; in
#' this case, all traces would have the same time-zero).
#' 
#' This function is a wrapper for the following commands:
#' * `tfb <- pickFirstBreak(obj, ...)`
#' * `t0 <- firstBreakToTime0(obj, tfb)`
#' * `time0(obj) <- t0` (if `FUN` is not `NULL` else `time0(obj) <- FUN(t0, ...)`)
#' 
#' 
#' Modified slots:
#' * `time0`: new estimated time-zero.
#' * `proc`: updated with function name and arguments.
#'
#' @param obj (`GPR`) An object of the class `GPR
#' @param method (`character[1]) Method to be applied (either
#'              `"coppens"`, `"threshold"` or `"MER"`). 
#'              `"coppens"` corresponds to the modified Coppens method, 
#'              `"threshold"` to the threshold method, 
#'              and `"MER"` to the modified energy ratio method.
#' @param thr (`numeric[1]`] Threshold for the signal 
#'              amplitude (in percent) at which time zero is picked (only for the
#'              threshold method). 
#'              `thr` ranges between 0 (0 percent) and 1 (100 percent).
#' @param w (`numeric[1]`) Length of the short-term leading window in 
#'          unit of time (only for `method = "coppens"` or 
#'          `method = "MER"`). 
#'          Recommended value: about one period of the first-arrival 
#'          waveform.
#' @param ns (`numeric[1]`] Length of the edge preserving smoothing 
#'           window in unit of time (only for  `method = "coppens"`). 
#'           Recommended value: between one and two signal periods.
#'           When `ns = NULL` the value of `ns` is set to 
#'           `1.5 * w`.
#' @param bet (`numeric[1]`) Stabilisation constant (only for 
#'            `method = "coppens"`). Not critical. 
#'            When `bet = NULL` the value of `bet` is set to 
#'            20 percent of the maximal signal amplitude.
#' @param shorten (`logical[1]`) If `TRUE`, each trace is shortened
#'                 by removing the samples that are \eqn{2 \times w} after the
#'                 maximum value (only for `method = "coppens"` or 
#'                 `method = "MER"`). You may set 
#'                 `shorten = FALSE` if the first wave break occurs 
#'                 after the maximum absolute amplitude time.
#' @param c0     (`numeric[1]`) Propagation speed of the GPR wave 
#'               through air in unit of space per unit of time 
#'               (generally in m/ns).
#' @param FUN (`function()`) A function to apply on the 
#'            estimated time-zero of every traces (e.g., `mean` or 
#'            `median` to get set a single time-zero value to the data).
#' @param ...  Further arguments to be passed to `FUN`.
#' @param track (`logical[1]`) Should the processing step be tracked? 
#' @return (`GPR`) An object of the class `GPR`.
#' @seealso [RGPR::pickFirstBreak()] to estimate the first wave break;
#'          [RGPR::firstBreakToTime0()] to convert the first wave break
#'          into time zero.
#'          [RGPR::time0()] and [RGPR::setTime0()] to set time-zero;
#'          [RGPR::shiftToTime0()] to shift the traces such that they start
#'          at time-zero.
#' @name estimateTime0
#' @rdname estimateTime0
#' @export
#' @concept processing
setGeneric("estimateTime0",
                function(obj, method = c("coppens", "threshold", "MER"), 
                         thr = NULL, w = NULL, ns = NULL, bet = NULL, 
                         shorten = TRUE, c0 = 0.299, 
                         FUN = NULL, ..., track = TRUE)
                  standardGeneric("estimateTime0"))




#' @rdname estimateTime0
#' @export
setMethod("estimateTime0", "GPR", 
          function(obj, method = c("coppens", "threshold", "MER"), 
                   thr = NULL, w = NULL, ns = NULL, bet = NULL, 
                   shorten = TRUE, c0 = 0.299, 
                   FUN = NULL, ..., track = TRUE){
            
            method <- method[1]
            
            # # shorten the file -> computed only for argument checking
            # nmax <- nrow(obj)
            # tst <- which(as.matrix(obj) == max(obj), arr.ind = TRUE)
            # if(length(tst) > 0 ){
            #   nmax <- max(tst[,"row"])
            # }
            
            #------------------- check arguments
            msg <- checkArgInit()
            msg <- checkArg(method,  msg, "STRING_CHOICE", 
                            c("coppens", "threshold",  "MER"))
            msg <- checkArg(thr,     msg, "PERCENT1_NULL")
            msg <- checkArg(w,       msg, "NUMERIC1_SPOS_NULL", max(obj@z)/2)
            # msg <- checkArg(ns     , msg, "NUMERIC1_SPOS_NULL", round((nmax - 1) * obj@dz))
            msg <- checkArg(ns,      msg, "NUMERIC1_SPOS_NULL", max(obj@z))
            msg <- checkArg(bet,     msg, "NUMERIC1_SPOS_NULL", Inf)
            msg <- checkArg(shorten, msg, "LOGICAL_LEN", 1)
            msg <- checkArg(c0,      msg, "NUMERIC1_SPOS", Inf)
            msg <- checkArg(FUN,     msg, "FUNCTION_NULL")
            checkArgStop(msg)
            #-----------------------------------
            
            tfb <- pickFirstBreak(obj, method = method, thr = thr, w = w, 
                              ns = ns, bet = bet, shorten = shorten)
            t0 <- firstBreakToTime0(obj, tfb, c0 = c0)
            
            if(!is.null(FUN)) t0 <- FUN(t0, ...)
            
            obj <- setTime0(obj, t0, track = FALSE)
            
            # obj@proc <- obj@proc[-length(obj@proc)] # remove proc "time0()<-"
            if(isTRUE(track)) proc(obj) <- getArgs()
            return(obj)
          })