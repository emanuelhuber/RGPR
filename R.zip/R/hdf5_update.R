


# ------------------------------------------------------------------------- #
# Delete an HDF5 link if it exists
# ------------------------------------------------------------------------- #
.delete_h5_link_if_exists <- function(group, name) {
  if (length(name) != 1L || is.na(name) || !nzchar(name)) {
    return(invisible(FALSE))
  }
  
  if (!name %in% names(group)) {
    return(invisible(FALSE))
  }
  
  group$link_delete(name)
  invisible(TRUE)
}


# ------------------------------------------------------------------------- #
# Write coordinate matrix for selected GPRsurvey lines to HDF5
.write_GPRsurvey_coords_hdf5 <- function(x, ids) {
  
  ids <- unique(as.integer(ids))
  ids <- ids[!is.na(ids)]
  
  if (length(ids) == 0L) {
    return(invisible(NULL))
  }
  
  if (isTRUE(x@view)) {
    message(
      "This GPRsurvey object is a view of an existing HDF5 file. ",
      "Coordinates were not written to the HDF5 file. ",
      "Use materialize(x, dsn = ...) first if you want an independent, writable survey."
    )
    return(invisible(NULL))
  }
  
  h5 <- hdf5r::H5File$new(x@path, mode = "a")
  on.exit(h5$close_all(), add = TRUE)
  
  if (!"lines" %in% names(h5)) {
    stop(
      "The HDF5 backing file has no '/lines' group.",
      call. = FALSE
    )
  }
  
  lines_group <- h5[["lines"]]
  
  for (id in ids) {
    line_name <- x@names[id]
    if (!line_name %in% names(lines_group)) {
      stop(
        "Line group not found in HDF5 file: '/lines/", line_name, "'.",
        call. = FALSE
      )
    }
    coord <- x@coords[[id]]
    if (is.null(coord) || length(coord) == 0L) {
      next
    }
    # coord <- as.matrix(coord)
    
    if (ncol(coord) != 3L) {
      stop(
        "Coordinates for line '", line_name,
        "' must have three columns.",
        call. = FALSE
      )
    }
    
    if (nrow(coord) != x@nx[id]) {
      stop(
        "Number of coordinate rows for line '", line_name,
        "' does not match the number of traces.",
        call. = FALSE
      )
    }
    line_group <- lines_group[[line_name]]
    
    coord_group <- if ("coords" %in% names(line_group)) {
      line_group[["coords"]]
    } else {
      line_group$create_group("coords")
    }
    
    if ("xyz" %in% names(coord_group)) {
      
      ds <- coord_group[["xyz"]]
      
      if (all(ds$dims == dim(coord))) {
        ds[,] <- coord
      } else {
        ds$close()
        .delete_h5_link_if_exists(coord_group, "xyz")
        coord_group[["xyz"]] <- coord
      }
      
    } else {
      coord_group[["xyz"]] <- coord
    }
  }
  
  h5$flush()
  
  invisible(NULL)
}
# .write_GPRsurvey_coords_hdf5 <- function(x, ids, coord_dataset = "coords") {
#   ids <- unique(as.integer(ids))
#   ids <- ids[!is.na(ids)]
#   if (length(ids) == 0L) {
#     return(invisible(NULL))
#   }
#   
#   if (isTRUE(x@view)) {
#     message(
#       "This GPRsurvey object is a view of an existing HDF5 file. ",
#       "Coordinates were not written to the HDF5 file. ",
#       "Use materialize(x, dsn = ...) first if you want an independent, writable survey."
#     )
#     return(invisible(NULL))
#   }
#   
#   if (!requireNamespace("hdf5r", quietly = TRUE)) {
#     stop("Package 'hdf5r' is required to update the GPRsurvey HDF5 file.", call. = FALSE)
#   }
#   
#   h5 <- hdf5r::H5File$new(x@path, mode = "a")
#   on.exit(h5$close_all(), add = TRUE)
#   
#   if (!"lines" %in% names(h5)) {
#     stop("The HDF5 backing file has no '/lines' group.", call. = FALSE)
#   }
#   
#   lines_group <- h5[["lines"]]
#   
#   for (id in ids) {
#     line_name <- x@names[id]
#     
#     if (!line_name %in% names(lines_group)) {
#       stop(
#         "Line group not found in HDF5 file: '/lines/", line_name, "'.",
#         call. = FALSE
#       )
#     }
#     
#     coord <- x@coords[[id]]
#     
#     if (is.null(coord) || length(coord) == 0L) {
#       next
#     }
#     
#     coord <- as.matrix(coord)
#     
#     if (ncol(coord) != 3L) {
#       stop(
#         "Coordinates for line '", line_name, "' must have three columns.",
#         call. = FALSE
#       )
#     }
#     
#     if (nrow(coord) != x@nx[id]) {
#       stop(
#         "Number of coordinate rows for line '", line_name,
#         "' does not match the number of traces.",
#         call. = FALSE
#       )
#     }
#     
#     colnames(coord) <- c("x", "y", "z")
#     
#     line_group <- lines_group[[line_name]]
#     
#     coord_group <- line_group[["coords"]]
#     
#     if ("xyz" %in% names(coord_group)) {
#       
#       ds <- coord_group[["xyz"]]
#       
#       if (all(dim(ds) == dim(coord))) {
#         ds[,] <- coord
#       } else {
#         ds$close()
#         .delete_h5_link_if_exists(coord_group, "xyz")
#         coord_group[["xyz"]] <- coord
#       }
#       
#     } else {
#       coord_group[["xyz"]] <- coord
#     }
#     
#     # .delete_h5_link_if_exists(line_group, coord_dataset)
#     # 
#     # line_group[[coord_dataset]] <- coord
#     # line_group[[coord_dataset]]$create_attr("colnames", colnames(coord))
#   }
#   
#   h5$flush()
#   
#   invisible(NULL)
# }


# Copy one line group between HDF5 files using hdf5r::copy_to()
#
# src_h5 and dst_h5 are open hdf5r::H5File objects.
# src_name and dst_name are group names under /lines.

.copy_h5_line_group <- function(src_h5, dst_h5, src_name, dst_name) {
  if (!"lines" %in% names(src_h5)) {
    stop("Source HDF5 file has no '/lines' group.", call. = FALSE)
  }
  
  if (!"lines" %in% names(dst_h5)) {
    dst_h5$create_group("lines")
  }
  
  src_lines <- src_h5[["lines"]]
  dst_lines <- dst_h5[["lines"]]
  
  if (!src_name %in% names(src_lines)) {
    stop(
      "Source line group not found in HDF5 file: '/lines/", src_name, "'.\n",
      "Available source line groups are:\n  ",
      paste(names(src_lines), collapse = ", "),
      call. = FALSE
    )
  }
  
  if (dst_name %in% names(dst_lines)) {
    dst_lines$link_delete(dst_name)
  }
  
  src_lines$obj_copy_to(
    dst_loc  = dst_lines,
    dst_name = dst_name,
    src_name = src_name
  )
  
  invisible(NULL)
}



#' Write line intersection data into the HDF5 file
#'
#' Writes the \code{@intersections} slot (if non-empty) to
#' \code{/survey/intersections/} as a dataset of crossing coordinates.
#' Called once at the end of the constructor, after \code{intersect()}.
#'
#' @param h5     Open \code{hdf5r} H5File object.
#' @param obj \code{GPRsurvey} object returned by \code{intersect()}.
#'
#' @keywords internal
.write_intersections_hdf5 <- function(h5, obj) {
  if (!.hasSlot(obj, "intersections")) return(invisible(NULL))
  ints <- obj@intersections
  if (length(ints) == 0L)              return(invisible(NULL))
  
  # Make sure /survey exists
  if (!"survey" %in% names(h5)) {
    sg <- h5$create_group("survey")
  } else {
    sg <- h5[["survey"]]
  }
  
  # Remove old /survey/intersections if it exists
  if ("intersections" %in% names(sg)) {
    sg$link_delete("intersections")
  }
  
  # Create fresh /survey/intersections
  ig <- sg$create_group("intersections")
  
  for (nm in names(ints)) {
    val <- ints[[nm]]
    
    if (is.numeric(val) && length(val) > 0L) {
      ig[[nm]] <- val
    }
  }
  
  h5$flush()
  
  invisible(NULL)
}

