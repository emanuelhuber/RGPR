
#' Apply batch processing to a GPRsurvey object
#'
#' Applies a list of processing functions to each GPR line of a materialized
#' \code{GPRsurvey}. The processed lines are written back to the HDF5 backing
#' file. Survey-level metadata and intersections are updated once at the end,
#' which is more efficient than replacing each line through \code{[[<-}.
#'
#' @param obj Object of class \code{GPRsurvey}.
#' @param prc A named list of processing functions and their arguments.
#'
#' @return A processed \code{GPRsurvey} object.
#'
#' @name papply
#' @rdname papply
#' @export
#' @concept processing
setGeneric("papply", function(obj, prc = NULL) standardGeneric("papply"))


#' @rdname papply
#' @export
setMethod("papply", "GPRsurvey", function(obj, prc = NULL) {
  
  if (isTRUE(obj@view)) {
    message(
      "This GPRsurvey object is a view of an existing HDF5 file. ",
      "The processing was not written to the HDF5 file, and the object ",
      "is returned unchanged. Use materialize(x, dsn = ...) first if ",
      "you want an independent, writable survey."
    )
    return(obj)
  }
  
  if (!is.list(prc)) {
    stop("'prc' must be a list.", call. = FALSE)
  }
  
  if (length(prc) == 0L) {
    return(obj)
  }
  
  if (is.null(names(prc)) || any(!nzchar(names(prc)))) {
    stop("'prc' must be a named list of processing functions.", call. = FALSE)
  }
  
  for (i in seq_along(obj)) {
    y <- verboseF(obj[[i]], verbose = FALSE)
    
    message("Processing ", y@name, "...", appendLF = FALSE)
    
    for (k in seq_along(prc)) {
      fun <- names(prc)[k]
      y <- do.call(fun, c(list(obj = y), prc[[k]]))
    }
    
    obj <- .replace_one_GPRsurvey_line(
      x                    = obj,
      i                    = i,
      value                = y,
      update_survey        = FALSE,
      update_intersections = FALSE
    )
    
    message(" done!", appendLF = TRUE)
  }
  
  # -------------------------------------------------------------------------
  # Global updates only once
  # -------------------------------------------------------------------------
  
  obj@intersections <- list()
  obj <- findIntersection(obj)
  
  h5 <- hdf5r::H5File$new(obj@path, mode = "a")
  on.exit(h5$close_all(), add = TRUE)
  
  .write_survey_metadata_hdf5(h5, obj)
  .write_intersections_hdf5(h5, obj)
  
  validObject(obj)
  
  obj
})
# setMethod("papply", "GPRsurvey", function(obj, prc = NULL){
#   if (isTRUE(obj@view)) {
#     message(
#       "This GPRsurvey object is a view of an existing HDF5 file. ",
#       "The replacement was not written to the HDF5 file, and the object ",
#       "is returned unchanged. Use writeGPRsurvey(x, dsn = ...) first if ",
#       "you want an independent, writable survey."
#     )
#     return(obj)
#   }
#   if(typeof(prc) != "list") stop("'prc' must be a list")
#   # zunits <- vector(mode = "character", length = length(obj))
#   for(i in seq_along(obj)){
#     y <- verboseF( obj[[i]], verbose = FALSE )
#     message('Processing ', y@name, '...', appendLF = FALSE)
#     for(k in seq_along(prc)){
#       y <- do.call(names(prc[k]), c(obj = y,  prc[[k]]))
#     }
#     obj[[i]] <- y
#     # obj@paths[i] <- .saveTempFile(y)
#     # obj@names[i]        <- y@name
#     # obj@descs[i]        <- y@desc
#     # obj@modes[i]        <- y@mode
#     # 
#     # obj@dates[i]        <- y@date
#     # 
#     # obj@freqs[i]        <- y@freq
#     # obj@antseps[i]      <- y@antsep
#     # 
#     # # obj@coordref
#     # if(length(y@coord) > 0){
#     #   obj@coords[[i]] <- y@coord
#     # } 
#     # 
#     # # obj@intersections
#     # obj@markers[[i]]  <- trimStr(y@markers)
#     # 
#     # obj@nz[i]         <- nrow(y@data)
#     # obj@zlengths[i]   <- diff(range(y@z, nr.rm = TRUE))
#     # obj@zunits[i]     <- y@zunit
#     # obj@nx[i]         <- ncol(y@data)
#     # obj@xlengths[i]   <-ifelse(length(y@coord) > 0,
#     #                            tail(relPos(y[,1:2]), 1),
#     #                            diff(range(x@x, na.rm = TRUE)))
#     message(' done!', appendLF = TRUE)
#   }
#   # obj@intersections <- list()
#   # obj <- setCoordref(obj)
#   return(obj)
# } 
# )

#' @name papply
#' @rdname papply
#' @export
setMethod("papply", "GPR", function(obj, prc = NULL){
  if(typeof(prc) != "list") stop("'prc' must be a list")
  for(k in seq_along(prc)){
    obj <- do.call(names(prc[k]), c(obj = obj,  prc[[k]]))
    message("*", appendLF = FALSE)
  }
  message("")
  return(obj)
} 
)