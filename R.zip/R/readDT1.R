# requires following functions:
# - '.getHD()'


# ============================================================================ #
# io-dt1.R
#
# Sensors & Software  —  DT1 + HD (+ GPS)
#
# Mandatory : *.dt1 (data), *.hd (header)
# Optional  : *.gps (GPS coordinates)
# ============================================================================ #





#' Read a Sensors & Software GPR file (.dt1 + .hd)
#'
#' Format-specific reader called by the dispatcher.  Not intended to be called
#' directly by users; use \code{\link{readGPR}} instead.
#'
#' @param dsn     Named list with slots \code{DT1}, \code{HD}, and optionally
#'                \code{GPS} (character paths or open connections).
#' @param fName   (`character(1)`) Base filename of the primary (.dt1) file.
#' @param fPath   (`character(1)`) Full path of the primary (.dt1) file.
#' @param desc    (`character(1)`) Short data description.
#' @param Vmax    (`numeric(1)|NULL`) Nominal input voltage for bit conversion.
#' @param verbose (`logical(1)`) Print progress messages.
#' @param ...     Currently unused; reserved for future use.
#'
#' @return A named list with:
#'   \item{x}{Object of class \code{GPR}.}
#'   \item{x_gps}{An \code{sf} object with GPS data, or \code{NULL}.}
#'
#' @keywords internal
.read_dt1 <- function(dsn, fName, fPath, desc, Vmax, verbose, ...) {

  hd  <- verboseF(readHD(dsn[["HD"]]),  verbose = verbose)
  dt1 <- verboseF(readDT1(dsn[["DT1"]], ntr = hd$ntr, npt = hd$npt),
                  verbose = verbose)

  x <- verboseF(
    .gprDT1(list(hd = hd$HD, dt1 = dt1$dt1hd, data = dt1$data),
            fName = fName, fPath = fPath, desc = desc, Vmax = Vmax),
    verbose = verbose
  )

  x_gps <- NULL
  if (!is.null(dsn[["GPS"]])) {
    x_gps <- verboseF(readGPS(dsn[["GPS"]], UTM = FALSE), verbose = verbose)
    # UTM projection is handled centrally in .maybe_interp_gps()
  }

  list(x = x, x_gps = x_gps)
}


# ---------------------------------------------------------------------------- #
# Format registration
# ---------------------------------------------------------------------------- #
register_gpr_format(
  id         = "DT1",
  detect_ext = "DT1",
  mandatory  = c(DT1 = "DT1", HD = "HD"),
  optional   = c(GPS = "GPS"),
  gps_ext   = "GPS",
  reader_fn  = .read_dt1
)


# ---------------------------------------------------------------------------- #
# private function - constructor
# x = list containing all the data
# return object of class GPR

# Private function read DT1
# @export
.gprDT1 <- function(x, fName = character(0), desc = character(0),
                 fPath = character(0), Vmax = NULL){
  
  if(is.null(Vmax)) Vmax <- 50
  
  coord_rec   <- cbind(x$dt1$recx,   x$dt1$recy,   x$dt1$recz)
  coord_trans <- cbind(x$dt1$transx, x$dt1$transy, x$dt1$transz)
  if(sum(is.na(coord_rec)) > 0){
    warning(paste(fName,": ", sum(is.na(coord_rec)), 
                  "NA's in the receiver coordinates\n"))
  }
  if(sum(is.na(coord_trans)) > 0){
    warning(paste(fName,": ", sum(is.na(coord_trans)), 
                  "NA's in the transmitter coordinates\n"))
  }
  if(sum(is.na(x$dt1$topo)) > 0){
    warning(paste(fName,": ", sum(is.na(x$dt1$topo)), 
                  "NA's in the topo coordinates\n"))
  }
  if(sum(abs(coord_rec), na.rm = TRUE) == 0 ){
    coord_rec <- matrix(nrow = 0, ncol = 0) 
  }
  if(sum(abs(coord_trans), na.rm = TRUE) == 0){
    coord_trans <- matrix(nrow = 0, ncol = 0) 
  }
  if(sum(abs(x$dt1$topo), na.rm = TRUE) == 0){
    coord <- matrix(nrow = 0, ncol = 0) 
  }else{
    coord <- matrix(0, nrow = ncol(x$data), ncol = 3)
    coord[,3] <- x$dt1$topo
    # coord[,1] <- x$dt1$pos  #FIXME
  }
  #------------ HEADER DATA (FILE *.HD)
  ttw  <- .getHD(x$hd, "TOTAL TIME WINDOW")
  if(!is.null(ttw)){
    dz <- as.numeric(ttw) / nrow(x$data)
  }else{
    warning("time/depth resolution unknown! I take dz = 0.4 ns!\n")
    dz <- 0.4
    ttw  <- nrow(x$data) * dz
  }
  
  tzap <- .getHD(x$hd, "TIMEZERO AT POINT")
  if( sum(abs(x$dt1$time0)) == 0 ){
    if(!is.null(tzap)){
      time_0 <- rep(as.numeric(tzap)*dz - dz, ncol(x$data))
    }
  }else{
    time_0 <- x$dt1$time0
  }
  
  posunit <- .getHD(x$hd, "POSITION UNITS")
  if(is.null(posunit)){
    posunit <- "m"
    #FIXME -> show how to set the unit
    message("X unit (trace position) set to 'm' (meter).")
  }
  
  antfreq <- .getHD(x$hd, "NOMINAL FREQUENCY")
  if(!is.null(antfreq)){
    antfreq <- freqFromString(antfreq)
  }else{
    antfreq <- NA_real_
    # message("Antenna frequency set to 0 MHz. Set it with 'antfreq(x) <- ... '")
  }
  
  antsep <- .getHD(x$hd, "ANTENNA SEPARATION")
  if(is.null(antsep)){
    antsep <- NA_real_
    # message("Antenna separation set to 0 ", posunit, 
    #         ". Set it with 'antsep(x) <- ... '")
  }else{
    antsep <- as.numeric(antsep)
  }
  
  surveymode <- .getHD(x$hd, "SURVEY MODE")
  if(is.null(surveymode)){
    surveymode <- "CO"
  }else{
    if(grepl("reflection", surveymode, ignore.case = TRUE)){
      surveymode <- "CO"
    }else if(grepl("CMP", surveymode, ignore.case = TRUE)){
      surveymode <- "CMP"
    }
  }
  

  sup_hd <- list()

  #--- survey date
  allhd <- gsub(pattern ="[^0-9]", replacement = "-", x$hd$val)
  # 2014-04-10 (new PulseEkko format)
  yyyymmdd <- "^([0-9]{4})([^0-9])([0-9]{2})([^0-9])([0-9]{2})"
  # 10/06/2011 (old PulseEkko format)
  ddmmyyyy <- "^([0-9]{2})([^0-9])([0-9]{2})([^0-9])([0-9]{4})"
  idx <- grep(yyyymmdd, allhd)
  d <- warnings("Could not understand the survey date\n")
  d <- Sys.Date()
  if(length(idx) > 0){
    d <- as.Date(allhd[idx[1]], "%Y-%m-%d")
  }else{
    idx <- grep(ddmmyyyy, allhd)
    if(length(idx) > 0){
      d <- as.Date(allhd[idx[1]], "%d-%m-%Y")
    }
  }
  
  traceTime <- as.double(as.POSIXct(x$dt1$time, origin = d))
  sup_hd[["clip"]] <- clippedBits(x$data, nbits = 16)
  sup_hd[["hd"]] <- x$hd
  xdata <- bits2volt(Vmax = Vmax)*x$data
  colnames(xdata) <- seq_len(ncol(x$data))
  if(is.null(Vmax)){
    dunit <- "bits"
  }else{
    dunit <- "mV"
  }
  new("GPR",   
      #--- class GPRvirtual
      version      = "0.3",  
      name         = fName,
      path         = fPath,
      desc         = desc,
      mode         = surveymode,
      date         = d,
      freq         = antfreq, 
      
      data         = xdata,     
      dunit        = dunit,  
      dlab         = "amplitude", 
      
      spunit       = "",  
      crs          = NA_character_,  
      #crs          = "",  
       
      xunit        = posunit,  
      xlab         = "position",
      
      zunit        = "ns",  
      zlab         = "two-way travel time",
      
      vel          = list(v = 0.1),   
      
      # proc         = "list",
      # delineations = "list",
      md           = sup_hd,  
      
      #--- class GPR
      z0           = time_0,    
      time         = traceTime,    
      antsep       = antsep,    
      markers      = trimStr(x$dt1$com), 
      # ann          = "character", 
      
      coord        = coord,     
      rec          = coord_rec,     
      trans        = coord_trans,     
      
      x            = round(x$dt1$pos, 5),     
      z            = seq(0, by = dz, length.out = nrow(x$data))  
      
      # angles      = "matrix" 
  )
}



# ---------------------------------------------------------------------------- #
#' Read Sensors and Software GPR data
#' 
#' @param dsn (`character(1)|connection object`) data source name: 
#'            either the filepath to the GPR data (character),
#'            or an open file connection.
#' @param ntr (`integer(1)`) Number of traces (given by .hd file)
#' @param npt (`integer(1)`) Number of samples per traces (given by .hd file)
#' @return (`list(2)`) Two-elements list: `dt1hd` with trace header and
#'         `data` with the traces.
#' @seealso [RGPR::readHD()], [RGPR::readGPS()]
#' @name readDT1
#' @rdname readDT1
#' @export
#' @concept I/O
readDT1 <- function(dsn, ntr, npt){
  dsn <- .openFileIfNot(dsn)
  on.exit(.closeFileIfNot(dsn))
  tags <- c("traces", "position", "samples", "topo", "NA1", "bytes",
            "window", "stacks", 
            "GPSx", "GPSy", "GPSz", 
            "recx", "recy", "recz",
            "transx", "transy", "transz",
            "time0", "zeroflag", "NA7", "time", "flag", "com")
  binSize <- rep(4, 23)
  binSize[9:11] <- 8
  binSize[23] <- 28
  binMod <- rep("numeric", 23)
  binMod[23] <- "character"
  
  
  hDT1 <- list()
  dataDT1 <- matrix(NA, nrow = npt, ncol = ntr)
  
  for(i in 1:ntr){
    for(j in 1:23){
      hDT1[[tags[j]]][i] <- readBinary(dsn, what = binMod[j], n = 1L, 
                                       size =  binSize[j])
    }
    # read the npt * 2 bytes trace data
    dataDT1[,i] <- readBinary(dsn, what = "integer", n = npt, size = 2)
  }
  # .closeFileIfNot(dsn)
  return( list(dt1hd = hDT1, data = dataDT1) )
}
# ---------------------------------------------------------------------------- #

#' Read Sensors and Software .HD file
#' 
#' @param dsn (`character(1)|connection object`) data source name: 
#'            either the filepath to the GPR data (character),
#'            or an open file connection.
#' @return (`list(3)`)  Three-elements list: `HD` containing the 
#'         header info, `ntr` the number of trace and `npt` the
#'         number of points per trace.
#' @seealso [RGPR::readDT1()], [RGPR::readGPS()]
#' @name readHD
#' @rdname readHD
#' @export
readHD <- function(dsn){
  # scan header file
  headHD <- scan(dsn, what = character(), strip.white = TRUE,
                 quiet = TRUE, fill = TRUE, blank.lines.skip = TRUE, 
                 flush = TRUE, sep = "\n")
  on.exit(.closeFileIfNot(dsn))
  hHD <- data.frame( tag = character(), 
                     val = character(), 
                     stringsAsFactors = FALSE)
  for(i in seq_along(headHD)){
    hdline <- strsplit(headHD[i], "=")[[1]]
    if(length(hdline) < 2){
      hHD[i,1] <- ""
      hHD[i,2] <- trimStr(hdline[1])
    }else{
      hHD[i,1:2] <-  as.character(sapply(hdline[1:2], trimStr))
    }
  }
  ntr <- as.integer(.getHD(hHD, "NUMBER OF TRACES"))
  npt <- as.integer(.getHD(hHD, "NUMBER OF PTS/TRC"))
  # .closeFileIfNot(dsn)
  return(list(HD = hHD, ntr = ntr, npt = npt))
}

# ---------------------------------------------------------------------------- #

#' Read Sensors and Software .GPS file
#' 
#' @param dsn (`character[1]|connection`) data source name: 
#'             either the filepath to the GPR data (character),
#'            or an open file connection.
#' @param UTM (`logical[1]`) If `TRUE` project coordinates to 
#'              the corresponding UTM zone. 
#' @return (`sf|data.frame|NULL`) Either an object of class
#'         `sf` or a `data.frame` or `NULL` if no
#'         coordinates could be extracted.
#' @seealso [RGPR::readDT1()], [RGPR::readHD()]
#' @name readGPS
#' @rdname readGPS
#' @export
readGPS <- function(dsn, UTM = TRUE){
  X <- .readGPS(dsn)
  if(length(X$tr_id) == 0) return(NULL)
  if(X$type == "GNGGA"){
    xyzt <- .getLonLatFromGNGGA(X$gpgga)
  }else if(X$type == "GPGGA"){
    xyzt <- .getLonLatFromGPGGA(X$gpgga)
  }
  
  out <-projectXYZT(xyzt, UTM = UTM, 
              NS = X[[tolower(X$type)]]$NS,
              EW = X[[tolower(X$type)]]$EW)
  
  # xyzt_crs <- 4326
  # if(isTRUE(UTM)){
  #   topoUTM <-  lonLatToUTM(lat = xyzt[,2], 
  #                       lon = xyzt[,1], 
  #                       zone = NULL, 
  #                       south = (X[[tolower(X$type)]]$NS[1] == "S"),
  #                       west  = (X[[tolower(X$type)]]$EW[1] == "W"))
  #   xyzt[, 1:2] <- topoUTM$xy
  #   xyzt_crs <- topoUTM$crs
  # }else if(is.character(UTM)){
  #   UTM_crs <- UMTStringToEPSG(UTM)
  #   xyzt[, 1:2] <- sf::sf_project(from = "EPSG:4326", 
  #                               to   = paste0("EPSG:", UTM_crs), 
  #                               pts  = xyzt[, 1:2])
  #   xyzt_crs <- paste0("EPSG:", UTM_crs)
  # }
  mrk <- cbind(out$xyzt[ ,1:3], X$tr_id, X$tr_pos, out$xyzt[ ,4])
  names(mrk) <- c("x", "y", "z", "id", "pos", "time")
  mrk <- sf::st_as_sf(x      = mrk,
                      coords = c("x", "y", "z"),
                      crs    = out$xyzt_crs)
  # .closeFileIfNot(dsn)
  return(mrk)
}

.readGPS <- function(dsn){
  x <- scan(dsn, what = character(), sep = "\n", quiet = TRUE)
  on.exit(.closeFileIfNot(dsn))
  # fac <- 1
  test1 <- grepl("(\\$GPGGA)", x)
  if(any(test1)){
    type <- "GPGGA"
  }else{
    test2 <- grepl("(\\$GNGGA)", x)
    if(any(test2)){
      type <- "GNGGA"
    }else{
      stop("Problem - no GPGGA or GNGGA string. Please contact me\n",
           "emanuel.huber@pm.me")
    }
  }
  
  xtr <- which(grepl("Trace \\#[0-9]+", x, 
                     ignore.case = TRUE, useBytes = TRUE ))
  #if(length(xtr) != length(xgpgga)){}
  xgpgga <- integer(length(xtr) - 1)
  xtr <- c(xtr, nrow(x))
  todelete <- c()
  for(i in seq_along(xtr[-1])){
    for(j in (xtr[i] + 1):(xtr[i+1] - 1)){
      
      test <- grepl(paste0("(\\$", type, ")"), x[j], ignore.case = TRUE, useBytes = TRUE )
      if(isTRUE(test)){
        xgpgga[i] <- j
        # message(xtr[i], " - ", j)
        break
      }
    }
    if(!isTRUE(test)){
      todelete <- c(todelete, i)
    }
  }
  
  if(length(todelete) > 0){
    xtr <- xtr[-todelete]
    xgpgga <- xgpgga[-todelete]
  }
  
  
  # trace number
  # pat_tr <- "(\\#[0-9]+)"
  # matches <- regexpr(pat_tr, x[xtr], perl=TRUE)
  # first <- attr(matches, "capture.start") + 1
  # last <- first + attr(matches, "capture.length") - 1
  # tr_id <- as.integer(mapply(substring, x[xtr], first, last, 
  #                            USE.NAMES = FALSE))
  tr_id <- as.integer(extractPattern(x[xtr], pattern = "(\\#[0-9]+)", 
                                     start = 1, stop = -1))
  
  # trace position
  # pat_tr <- "(position [0-9]*\\.?[0-9]*)"
  # matches <- regexpr(pat_tr, x[xtr], perl=TRUE)
  # first <- attr(matches, "capture.start") + 9
  # last <- first + attr(matches, "capture.length")
  # tr_pos <- as.numeric(mapply(substring, x[xtr], first, last, 
  #                             USE.NAMES = FALSE))
  tr_pos <- as.numeric(extractPattern(x[xtr], 
                                      pattern = "(position [0-9]*\\.?[0-9]*)", 
                                      start = 9, stop = 0))
  
  pat_gpgga <- paste0("\\$(?<ID>[A-Z]+GGA),(?<UTC>[0-9.]+),(?<lat>[0-9.]+),",
                      "(?<NS>[NS]),(?<lon>[0-9.]+),(?<EW>[EW]),(?<fix>[0-9]),",
                      "(?<NbSat>[0-9.]+),(?<HDOP>[0-9.]+),(?<H>[0-9.]+),",
                      "(?<mf>[MmFf]+)") 
  #,(?<HGeoid>[0-9.]+),(?<mf2>[mMfF+),",
  # "(?<TDGPS>[0-9.]+),(?<DGPSID> [A-z0-9.]+)"
  # )
  
  # matches <- regexpr(pat_gpgga, x[xgpgga], perl=TRUE)
  # first <- attr(matches, "capture.start")
  # last <- first + attr(matches, "capture.length") -1
  # gpgga <- mapply(substring, x[xgpgga], first, last, USE.NAMES = FALSE)
  gpgga <- extractPattern(x[xgpgga], pattern = pat_gpgga, 
                          start = 0, stop = -1)
  
  dim(gpgga) <- c(length(xgpgga), 11)
  gpgga <- as.data.frame(gpgga, stringsAsFactors = FALSE)
  colnames(gpgga) <- c("ID", "UTC", "lat", "NS", "lon", "EW", 
                       "fix", "NbSat", "HDOP", "H", "mf")
  # gpgga$lat <- as.numeric(gpgga$lat) * fac
  # gpgga$lon <- as.numeric(gpgga$lon) * fac
  
  sel <- which(gpgga[,1] != "")
  
  tr_id <- tr_id[sel]
  tr_pos <- tr_pos[sel]
  gpgga <- gpgga[sel,]
  
  if(any(c(nrow(gpgga), length(tr_id)) != length(tr_pos))){
    stop("Problem - code 'qoiwelk'. Please contact me\n",
         "emanuel.huber@pm.me")
  }
  # .closeFileIfNot(dsn)
  return(list(tr_id = tr_id, tr_pos = tr_pos, gpgga = gpgga, type = type))
}


