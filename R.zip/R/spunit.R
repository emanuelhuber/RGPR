
#' Spatial unit
#' 
#' Spatial unit of the trace coordinates
#' @param x     (`GPR class`) An object of the class `GPR`
#' @param value (`character[1]`) Spatial units: "m", "feet", etc.
#'                                     see units package.
#' @return (`GPR class`) An object of the class `GPR`
#' @name spunit
setGeneric("spunit", function(x) 
  standardGeneric("spunit"))


#' @rdname spunit
#' @aliases spunit<-,GPR-method
setGeneric("spunit<-",function(x,value){standardGeneric("spunit<-")})


#-------------------------------- GPR -----------------------------------------#

#' @rdname spunit   
#' @export
setMethod("spunit", "GPR", function(x){
  return(x@spunit)
})

#' @rdname spunit
#' @export
setReplaceMethod("spunit", signature="GPR", function(x, value){
  if(is.na(x@crs)){
    x@spunit <- .checkUnit(value)
    x@proc <- c(x@proc, "spunit<-")
  }else{
    warning("Cannot change the spatial unit because it depends on the CRS. ",
            "Either update the CRS with 'crs(x) <- ...' or ",
            "'remove' the CRS with 'crs(x) <- NA'")
  }
  return(x)
})


#-------------------------------- GPRsurvey -----------------------------------#

#' @rdname spunit   
#' @export
setMethod("spunit", "GPRsurvey", function(x){
  return(x@spunit)
})


#' @rdname spunit
#' @export
setReplaceMethod("spunit", signature="GPRsurvey", function(x, value){
  if(is.na(x@crs)){
    if(length(value) > 1) warning("You set more than one 'spunit' value! ",
                                  "I can only accept one!\n",
                                  "I take the first one!")
    x@spunit <- .checkUnit(value[1])
  }else{
    warning("Cannot change the spatial unit because it depends on the CRS. ",
            "Either update the CRS with 'crs(x) <- ...' or ",
            "'remove' the CRS with 'crs(x) <- NA'")
  }
  return(x)
})

# # used in GPRsurvey.R
# .checkSpunitsurvey <- function(x){
#   sp_unit  <- unique(x[x != ""])
#   if(length(sp_unit) == 1){
#     return( .checkUnit(rep(sp_unit, length(x))) )
#   }else if(length(sp_unit) == 0){
#     return(x)
#   }else{
#     return( .checkUnit(x) )
#   }
# }
