
# GPRsurvey replacement methods for HDF5-backed surveys
#
# Supports:
#   SU[[2]]  <- gpr
#   SU[2]    <- gpr
#   SU[1:3]  <- list(gpr1, gpr2, gpr3)
#   SU[1:10] <- SU2
#
# If x@view is TRUE, replacement is ignored with a message and x is returned
# unchanged. If value is a GPRsurvey, line groups are copied directly between
# HDF5 files using hdf5r's copy_to() method, without reading all GPR data into R.


#----- extract [ ] ----

#' Extract and replace parts of a GPRsurvey object
#' 
#' Subsetting a GPRsurvey returns a view. A view does not create a new HDF5 
#' file. It remains backed by the original HDF5 file and is not modified in 
#' place.
#' 
#' Extract parts of a GPRsurvey object
#' @param x (`GPRsurvey`)
#' @param i (`integer`) Indices specifying elements to extract or replace.
#' @param j (`integer`) Not used.
#' @param ... Not used.
#' @param drop Not used.
#' @param exact Not used.
#' @return (`GPRsurvey`)
#' @aliases [,GPRsurvey-method
#' @rdname subset-GPRsurvey
#' @export
setMethod("[", signature(x = "GPRsurvey", i = "ANY", j = "ANY"),
          function(x, i, j, ..., drop = TRUE){
            if(missing(i)) i <- j
            # cat(typeof(i),"\n")
            # cat(j,"\n")
            # i <- as.numeric(i)
            y <- x
            y@paths          <- x@paths[i]
            y@names          <- x@names[i]
            y@descs          <- x@descs[i]
            y@modes          <- x@modes[i]
            
            y@dates          <- x@dates[i]
            y@freqs          <- x@freqs[i]
            y@antseps        <- x@antseps[i]
            
            if(length(x@spunit) == length(x@names)){
              y@spunit         <- x@spunit[i]
            }
            # FIXME
            if(length(x@crs) == 1){
              y@crs <- x@crs
            }else{
              y@crs <- x@crs[i]
            }
            y@coords         <- x@coords[i]
            y@markers        <- x@markers[i]
            y@intersections  <- list()
            y@nz             <- x@nz[i]
            y@zlengths       <- x@zlengths[i]
            y@zunits         <- x@zunits[i]
            y@nx             <- x@nx[i]
            y@xlengths       <- x@xlengths[i]
            y@transf         <- x@transf
            
            y@view           <- TRUE
            
            y <- findIntersection(y)
            
            return(y)
          })

#----- extract [[ ]] ----

#' @aliases [[,GPRsurvey-method
#' @rdname subset-GPRsurvey
#' @export
setMethod("[[", signature(x = "GPRsurvey", i = "ANY", j = "ANY"),
          function(x, i, j, ..., exact = TRUE){
            nm <- if (is.numeric(i)) x@names[[i]] else i
            if (!nm %in% x@names) {
              stop("Line '", nm, "' not found in this GPRsurvey.", call. = FALSE)
            }
            .read_GPR_line_hdf5(x@path, nm)
            
          })


#----- replace [ ] ----

#' @aliases [<-,GPR-method
#' @rdname subset-GPR
#' @export
setReplaceMethod(
  f = "[",
  signature = signature(x = "GPRsurvey", i = "ANY", j = "ANY", value = "ANY"),
  definition = function(x, i, j, ..., value) {
    if (isTRUE(x@view)) {
      message(
        "This GPRsurvey object is a view of an existing HDF5 file. ",
        "The replacement was not written to the HDF5 file, and the object ",
        "is returned unchanged. Use writeGPRsurvey(x, dsn = ...) first if ",
        "you want an independent, writable survey."
      )
      return(x)
    }
    
    ii <- .gprsurvey_index(x, i)
    
    # ------------------------------------------------------------------------ #
    # Case 1: replacement by another GPRsurvey
    # ------------------------------------------------------------------------ #
    if (inherits(value, "GPRsurvey")) {
      n_value <- length(value@names)
      
      if (n_value != length(ii)) {
        stop(
          "When 'value' is a GPRsurvey object, its length must match ",
          "the number of replacement indices.\n",
          "Length of 'i': ", length(ii), "\n",
          "Length of 'value': ", n_value,
          call. = FALSE
        )
      }
      
      same_file <- normalizePath(x@path, mustWork = TRUE) ==
        normalizePath(value@path, mustWork = TRUE)
      
      dst_h5 <- hdf5r::H5File$new(x@path, mode = "a")
      on.exit(dst_h5$close_all(), add = TRUE)
      
      if (same_file) {
        src_h5 <- dst_h5
      } else {
        src_h5 <- hdf5r::H5File$new(value@path, mode = "r")
        on.exit(src_h5$close_all(), add = TRUE)
      }
      
      # When source and destination are the same HDF5 file, first copy all source
      # groups to temporary groups. This protects source groups from being deleted
      # before they are copied, e.g. SU[1:2] <- SU[2:1].
      src_names <- value@names
      tmp_names <- character(0L)
      
      if (same_file) {
        tmp_names <- paste0(
          ".RGPR_tmp_replace_",
          format(Sys.time(), "%Y%m%d%H%M%OS6"),
          "_",
          seq_along(ii)
        )
        
        for (k in seq_along(ii)) {
          .copy_h5_line_group(
            src_h5   = src_h5,
            dst_h5   = dst_h5,
            src_name = value@names[k],
            dst_name = tmp_names[k]
          )
        }
        
        src_names <- tmp_names
      }
      
      for (k in seq_along(ii)) {
        old_name <- x@names[ii[k]]
        
        new_name <- value@names[k]
        if (length(new_name) == 0L || !nzchar(new_name)) {
          new_name <- "default_name"
        }
        new_name <- safeName(x = new_name, y = x@names[-ii[k]])
        
        if ("lines" %in% names(dst_h5)) {
          dst_lines <- dst_h5[["lines"]]
          .delete_h5_link_if_exists(dst_lines, old_name)
        }
        
        .copy_h5_line_group(
          src_h5   = src_h5,
          dst_h5   = dst_h5,
          src_name = src_names[k],
          dst_name = new_name
        )
        
        x <- .replace_one_GPRsurvey_line_from_survey(
          x        = x,
          i        = ii[k],
          value    = value,
          k        = k,
          dst_name = new_name
        )
      }
      
      if (same_file && length(tmp_names) > 0L) {
        dst_lines <- dst_h5[["lines"]]
        for (nm in tmp_names) {
          .delete_h5_link_if_exists(dst_lines, nm)
        }
      }
      
      x@intersections <- list()
      x <- findIntersection(x)
      
      .write_survey_metadata_hdf5(dst_h5, x)
      .write_intersections_hdf5(dst_h5, x)
      
      validObject(x)
      return(x)
    }
    
    # ------------------------------------------------------------------------ #
    # Case 2: replacement by one GPR
    # ------------------------------------------------------------------------ #
    if (inherits(value, "GPR")) {
      if (length(ii) != 1L) {
        stop(
          "A single GPR object can replace only one survey line. ",
          "For several lines, provide a list of GPR objects or a GPRsurvey ",
          "object of the same length as 'i'.",
          call. = FALSE
        )
      }
      value <- list(value)
    } else if (!is.list(value)) {
      stop(
        "'value' must be a GPR object, a list of GPR objects, ",
        "or a GPRsurvey object.",
        call. = FALSE
      )
    }
    
    ok <- vapply(value, inherits, logical(1L), what = "GPR")
    
    if (!all(ok)) {
      stop("All replacement elements must be of class 'GPR'.", call. = FALSE)
    }
    
    if (length(value) != length(ii)) {
      stop(
        "Number of replacement GPR objects does not match number of indices.\n",
        "Length of 'i': ", length(ii), "\n",
        "Length of 'value': ", length(value),
        call. = FALSE
      )
    }
    
    for (k in seq_along(ii)) {
      x <- .replace_one_GPRsurvey_line(
        x     = x,
        i     = ii[k],
        value = value[[k]]
      )
    }
    
    # validObject(x)
    x
  }
)


#----- replace [[ ]] ----

setReplaceMethod(
  f = "[[",
  signature = signature(x = "GPRsurvey", i = "ANY", j = "ANY", value = "GPR"),
  definition = function(x, i, j, ..., value) {
    if (isTRUE(x@view)) {
      message(
        "This GPRsurvey object is a view of an existing HDF5 file. ",
        "The replacement was not written to the HDF5 file, and the object ",
        "is returned unchanged. Use writeGPRsurvey(x, dsn = ...) first if ",
        "you want an independent, writable survey."
      )
      return(x)
    }
    
    ii <- .gprsurvey_index(x, i)
    
    if (length(ii) != 1L) {
      stop("[[<- can replace only one GPR line.", call. = FALSE)
    }
    
    .replace_one_GPRsurvey_line(x, ii, value)
  }
)

# ------------------------------------------------------------------------- #
# Helpers
# ------------------------------------------------------------------------- #


# Update one destination line's in-memory metadata from a source GPRsurvey line
# This does not read the GPR data matrix. The HDF5 line group is copied elsewhere.
.replace_one_GPRsurvey_line_from_survey <- function(x, i, value, k, dst_name) {
  new_name <- dst_name
  
  x@names[i]    <- new_name
  x@descs[i]    <- value@descs[k]
  x@modes[i]    <- value@modes[k]
  x@dates[i]    <- value@dates[k]
  x@freqs[i]    <- value@freqs[k]
  x@antseps[i]  <- value@antseps[k]
  x@nz[i]       <- value@nz[k]
  x@nx[i]       <- value@nx[k]
  x@zlengths[i] <- value@zlengths[k]
  x@xlengths[i] <- value@xlengths[k]
  x@zunits[i]   <- value@zunits[k]
  
  if (length(x@spunit) == length(x@names)) {
    if (length(value@spunit) == length(value@names)) {
      x@spunit[i] <- value@spunit[k]
    } else if (length(value@spunit) > 0L) {
      message("took the first spatial unit found!")
      x@spunit[i] <- value@spunit[1L]
    }
  }
  
  if (length(x@crs) == length(x@names)) {
    if (length(value@crs) == length(value@names)) {
      x@crs[i] <- value@crs[k]
    } else if (length(value@crs) > 0L) {
      message("took the first CRS found!")
      x@crs[i] <- value@crs[1L]
    }
  }
  
    
  if (length(value@coords) > 0L) {
    if (length(x@coords) == 0L) {
      x@coords <- vector("list", length(x@names))
      names(x@coords) <- x@names
    }
    
    x@coords[[i]] <- value@coords[[k]]
    names(x@coords)[i] <- new_name
  } else if (length(x@coords) > 0L) {
    x@coords[[i]] <- list()
    names(x@coords)[i] <- new_name
  }
  
  if (length(value@markers) > 0L) {
    if (length(x@markers) == 0L) {
      x@markers <- vector("list", length(x@names))
      names(x@markers) <- x@names
    }
    
    x@markers[[i]] <- value@markers[[k]]
    names(x@markers)[i] <- new_name
  } else if (length(x@markers) > 0L) {
    names(x@markers)[i] <- new_name
  }
  
  x
}


# Resolve replacement indices
.gprsurvey_index <- function(x, i) {
  if (missing(i)) {
    stop("Missing index.", call. = FALSE)
  }
  if (is.character(i)) {
    ii <- match(i, x@names)
    if (anyNA(ii)) {
      stop(
        "Line(s) not found in this GPRsurvey: ",
        paste(i[is.na(ii)], collapse = ", "),
        call. = FALSE
      )
    }
    return(ii)
  }
  ii <- as.integer(i)
  if (anyNA(ii) || any(ii < 1L) || any(ii > length(x@names))) {
    stop("Index out of bounds.", call. = FALSE)
  }
  ii
}

.gprsurvey_line_metadata <- function(gpr) {
  zlength <- if (length(gpr@z) > 1L) {
    abs(diff(range(gpr@z, na.rm = TRUE)))
  } else {
    0
  }
  
  xlength <- if (length(gpr@x) > 1L) {
    abs(diff(range(gpr@x, na.rm = TRUE)))
  } else {
    0
  }
  
  list(
    desc    = gpr@desc,
    mode    = gpr@mode,
    date    = .setSlotDefault(gpr, "date",   Sys.Date(), verbose = FALSE),
    freq    = .setSlotDefault(gpr, "freq",   0,          verbose = FALSE),
    antsep  = .setSlotDefault(gpr, "antsep", 0,          verbose = FALSE),
    spunit  = gpr@xunit,
    crs     = gpr@crs,
    coord   = gpr@coord,
    nz      = nrow(gpr),
    nx      = ncol(gpr),
    zlength = zlength,
    xlength = xlength,
    zunit   = gpr@zunit
  )
}


.write_survey_metadata_hdf5 <- function(h5, survey) {
  .delete_h5_link_if_exists(h5, "survey")
  
  sg <- h5$create_group("survey")
  
  sg$create_attr(
    "crs",
    if (length(survey@crs) == 0L || is.na(survey@crs[1L])) "" else survey@crs[1L]
  )
  
  sg$create_attr(
    "spunit",
    if (length(survey@spunit) == 0L || is.na(survey@spunit[1L])) "" else survey@spunit[1L]
  )
  
  sg[["names"]]    <- survey@names
  sg[["descs"]]    <- survey@descs
  sg[["modes"]]    <- survey@modes
  sg[["dates"]]    <- format(survey@dates, "%Y-%m-%d")
  sg[["freqs"]]    <- survey@freqs
  sg[["antseps"]]  <- survey@antseps
  sg[["nz"]]       <- survey@nz
  sg[["nx"]]       <- survey@nx
  sg[["zlengths"]] <- survey@zlengths
  sg[["xlengths"]] <- survey@xlengths
  sg[["zunits"]]   <- survey@zunits
  
  invisible(NULL)
}


.replace_one_GPRsurvey_line <- function(x, i, value,
                                        compress = 5L,
                                        update_survey = TRUE,
                                        update_intersections = TRUE) {
  if (!inherits(value, "GPR")) {
    stop("'value' must be of class 'GPR'.", call. = FALSE)
  }
  
  old_name <- x@names[i]
  
  new_name <- value@name[1L]
  if (length(new_name) == 0L || !nzchar(new_name)) {
    new_name <- "default_name"
  }
  
  new_name <- safeName(x = new_name, y = x@names[-i])
  value@name <- new_name
  
  meta <- .gprsurvey_line_metadata(value)
  
  # -------------------------------------------------------------------------
  # Update in-memory metadata
  # -------------------------------------------------------------------------
  
  x@names[i]    <- new_name
  x@descs[i]    <- meta$desc
  x@modes[i]    <- meta$mode
  x@dates[i]    <- meta$date
  x@freqs[i]    <- meta$freq
  x@antseps[i]  <- meta$antsep
  x@nz[i]       <- meta$nz
  x@nx[i]       <- meta$nx
  x@zlengths[i] <- meta$zlength
  x@xlengths[i] <- meta$xlength
  x@zunits[i]   <- meta$zunit
  
  if (length(x@spunit) == length(x@names)) {
    x@spunit[i] <- meta$spunit
  }
  
  if (length(x@crs) == length(x@names)) {
    x@crs[i] <- meta$crs
  } else if (
    length(x@crs) == 0L ||
    is.na(x@crs[1L]) ||
    !nzchar(x@crs[1L])
  ) {
    x@crs <- meta$crs
  }
  
  if (length(meta$coord) > 0L) {
    if (nrow(meta$coord) != ncol(value) || ncol(meta$coord) != 3L) {
      stop("Coordinates are not correct.", call. = FALSE)
    }
    
    if (length(x@coords) == 0L) {
      x@coords <- vector("list", length(x@names))
      names(x@coords) <- x@names
    }
    
    x@coords[[i]] <- meta$coord
    names(x@coords)[i] <- new_name
    
  } else if (length(x@coords) > 0L) {
    x@coords[[i]] <- list()
    names(x@coords)[i] <- new_name
    
    if (all(vapply(x@coords, length, integer(1L)) == 0L)) {
      x@coords <- list()
    }
  }
  
  if (length(x@markers) > 0L) {
    names(x@markers)[i] <- new_name
  }
  
  # -------------------------------------------------------------------------
  # Update HDF5 line only
  # -------------------------------------------------------------------------
  
  h5 <- hdf5r::H5File$new(x@path, mode = "a")
  on.exit(h5$close_all(), add = TRUE)
  
  lg <- h5[["lines"]]
  
  .delete_h5_link_if_exists(lg, old_name)
  
  .write_GPR_line_hdf5(
    lg,
    name     = new_name,
    gpr      = value,
    compress = compress
  )
  
  # -------------------------------------------------------------------------
  # Optional global updates
  # -------------------------------------------------------------------------
  
  if (isTRUE(update_intersections)) {
    x@intersections <- list()
    x <- findIntersection(x)
  }
  
  if (isTRUE(update_survey)) {
    .write_survey_metadata_hdf5(h5, x)
    .write_intersections_hdf5(h5, x)
  }
  
  validObject(x)
  
  x
}
# .replace_one_GPRsurvey_line <- function(x, i, value, compress = 5L) {
#   if (!inherits(value, "GPR")) {
#     stop("'value' must be of class 'GPR'.", call. = FALSE)
#   }
#   
#   old_name <- x@names[i]
#   
#   new_name <- value@name[1L]
#   if (length(new_name) == 0L || !nzchar(new_name)) {
#     new_name <- "default_name"
#   }
#   
#   new_name <- safeName(x = new_name, y = x@names[-i])
#   value@name <- new_name
#   
#   meta <- .gprsurvey_line_metadata(value)
#   
#   # ---- update in-memory metadata -----------------------------------------
#   
#   x@names[i]    <- new_name
#   x@descs[i]    <- meta$desc
#   x@modes[i]    <- meta$mode
#   x@dates[i]    <- meta$date
#   x@freqs[i]    <- meta$freq
#   x@antseps[i]  <- meta$antsep
#   x@nz[i]       <- meta$nz
#   x@nx[i]       <- meta$nx
#   x@zlengths[i] <- meta$zlength
#   x@xlengths[i] <- meta$xlength
#   x@zunits[i]   <- meta$zunit
#   
#   if (length(x@spunit) == length(x@names)) {
#     x@spunit[i] <- meta$spunit
#   }
#   
#   if (length(x@crs) == length(x@names)) {
#     x@crs[i] <- meta$crs
#   } else if (
#     length(x@crs) == 0L ||
#     is.na(x@crs[1L]) ||
#     !nzchar(x@crs[1L])
#   ) {
#     x@crs <- meta$crs
#   }
#   
#   if (length(meta$coord) > 0L) {
#     if (nrow(meta$coord) != ncol(value) || ncol(meta$coord) != 3L) {
#       stop("Coordinates are not correct.", call. = FALSE)
#     }
#     
#     if (length(x@coords) == 0L) {
#       x@coords <- vector("list", length(x@names))
#       names(x@coords) <- x@names
#     }
#     
#     x@coords[[i]] <- meta$coord
#     names(x@coords)[i] <- new_name
#   } else {
#     if (length(x@coords) > 0L) {
#       x@coords[[i]] <- NULL
#     }
#     
#     if (length(x@coords) > 0L && all(vapply(x@coords, length, integer(1L)) == 0L)) {
#       x@coords <- list()
#     }
#   }
#   
#   # Markers are line-specific. If the line name changes, keep the old marker
#   # object but rename it. If you prefer to drop markers on replacement, replace
#   # this block by x@markers[[i]] <- NULL.
#   if (length(x@markers) > 0L) {
#     names(x@markers)[i] <- new_name
#   }
#   
#   # Intersections depend on all lines, so recompute.
#   x@intersections <- list()
#   x <- findIntersection(x)
#   
#   # ---- update HDF5 ---------------------------------------------------------
#   
#   h5 <- hdf5r::H5File$new(x@path, mode = "a")
#   on.exit(h5$close_all(), add = TRUE)
#   
#   lg <- h5[["lines"]]
#   
#   .delete_h5_link_if_exists(lg, old_name)
#   .write_GPR_line_hdf5(lg, name = new_name, gpr = value, compress = compress)
#   
#   .write_survey_metadata_hdf5(h5, x)
#   .write_intersections_hdf5(h5, x)
#   
#   # validObject(x)
#   
#   x
# }
